import {WebRoutes} from "./web/route";


export const Routes = [
    ...WebRoutes,
]