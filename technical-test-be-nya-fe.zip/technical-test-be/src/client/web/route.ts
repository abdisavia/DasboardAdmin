import {ProductRoutes} from "./product/route";


export const WebRoutes = [
    ...ProductRoutes,
]